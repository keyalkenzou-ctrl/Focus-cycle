package com.example.focuscycle

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.app.Activity
import android.os.PowerManager
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FocusCycleScreen(this) }
    }

    override fun onResume() {
        super.onResume()
        // If the screen is currently interactive, it cannot count as an uninterrupted screen-off streak.
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (pm.isInteractive) CycleStore.clearScreenOff(this)
        CycleStore.refresh(this)
    }
}

@Composable
private fun FocusCycleScreen(activity: Activity) {
    var refresh by remember { mutableIntStateOf(0) }
    var accessibilityEnabled by remember { mutableStateOf(isAccessibilityEnabled(activity)) }
    var notificationsEnabled by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        while (true) {
            CycleStore.refresh(activity)
            accessibilityEnabled = isAccessibilityEnabled(activity)
            refresh++
            delay(1000)
        }
    }

    val phase = CycleStore.phase(activity)
    val remaining = CycleStore.nextTransitionRemaining(activity)
    val pm = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
    val interactive = pm.isInteractive
    val offQualified = !interactive && CycleStore.screenOffRemaining(activity) < 30 * 60 * 1000L

    MaterialTheme {
        Scaffold { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                horizontalAlignment = Alignment.Start
            ) {
                Text("FocusCycle", style = MaterialTheme.typography.headlineLarge)
                Text(
                    if (phase == Phase.FOCUS) "FASE FOKUS" else "FASE BEBAS",
                    style = MaterialTheme.typography.titleLarge,
                    color = if (phase == Phase.FOCUS) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.primary
                )
                Text(
                    when (phase) {
                        Phase.FOCUS -> if (offQualified) "Syarat layar mati sedang dihitung."
                            else "Untuk membuka fase bebas, matikan layar dan biarkan perangkat tidak digunakan selama 30 menit berturut-turut."
                        Phase.FREE -> "Akses bebas aktif. Setelah waktu habis, fase fokus dimulai otomatis saat aplikasi/layanan berjalan."
                    }
                )
                Text(
                    if (phase == Phase.FOCUS) "Sisa syarat: ${CycleStore.format(remaining)}"
                    else "Sisa akses bebas: ${CycleStore.format(remaining)}",
                    style = MaterialTheme.typography.headlineMedium
                )
                Divider()
                Text("Aplikasi yang ditargetkan", style = MaterialTheme.typography.titleMedium)
                Text("• TikTok\n• Instagram\n• Google Chrome")
                Text("Pembatasan ini bergantung pada Accessibility Service. Pengguna tetap dapat menghentikan layanan, mencabut izin, atau membuka aplikasi melalui cara lain.")
                Divider()
                Text("Pengaturan izin", style = MaterialTheme.typography.titleMedium)
                Text("1. Aktifkan Accessibility Service FocusCycle di Pengaturan Aksesibilitas.")
                Text("2. Jika diminta, izinkan notifikasi agar status dapat ditampilkan (notifikasi belum diperlukan untuk logika inti).")
                Text("3. Jangan optimalkan baterai secara agresif untuk FocusCycle jika ingin siklus lebih andal; nama menu berbeda antar perangkat.")
                Button(onClick = {
                    runCatching { activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
                }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (accessibilityEnabled) "Buka pengaturan aksesibilitas" else "Aktifkan Accessibility Service")
                }
                OutlinedButton(onClick = {
                    runCatching { activity.startActivity(Intent(Settings.ACTION_SETTINGS)) }
                }, modifier = Modifier.fillMaxWidth()) { Text("Buka Pengaturan Android") }
                Text(
                    "Catatan: Android dapat menunda proses latar belakang, menghentikan aplikasi, atau mengubah perilaku OEM. FocusCycle bukan parental-control/device-owner lock dan tidak menjamin pemblokiran tanpa celah."
                , style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

private fun isAccessibilityEnabled(context: Context): Boolean {
    val service = "${context.packageName}/${FocusAccessibilityService::class.java.name}"
    return try {
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.split(':')?.any { it.equals(service, ignoreCase = true) } == true
    } catch (_: Exception) { false }
}
