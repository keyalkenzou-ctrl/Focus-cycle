package com.example.focuscycle

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED) {
            // Do not silently re-enable Accessibility. User must verify the service in Settings.
            // If device restarted, elapsedRealtime is reset; clear any incomplete screen-off streak.
            CycleStore.clearScreenOff(context)
        }
    }
}
