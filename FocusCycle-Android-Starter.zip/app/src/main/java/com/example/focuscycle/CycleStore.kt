package com.example.focuscycle

import android.content.Context
import android.os.SystemClock

enum class Phase { FOCUS, FREE }

object CycleStore {
    private const val PREFS = "focuscycle"
    private const val KEY_PHASE = "phase"
    private const val KEY_OFF_ELAPSED = "screen_off_elapsed"
    private const val KEY_OFF_WALL = "screen_off_wall"
    private const val KEY_FREE_END = "free_end_wall"
    private const val KEY_FOCUS_END = "focus_end_wall"
    private const val FOCUS_MS = 30 * 60 * 1000L
    private const val FREE_MS = 30 * 60 * 1000L

    private fun prefs(c: Context) = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun phase(c: Context): Phase =
        if (prefs(c).getString(KEY_PHASE, "FOCUS") == "FREE") Phase.FREE else Phase.FOCUS

    fun setScreenOff(c: Context) {
        prefs(c).edit().putLong(KEY_OFF_ELAPSED, SystemClock.elapsedRealtime())
            .putLong(KEY_OFF_WALL, System.currentTimeMillis()).apply()
    }
    fun clearScreenOff(c: Context) {
        prefs(c).edit().remove(KEY_OFF_ELAPSED).remove(KEY_OFF_WALL).apply()
    }
    fun screenOffRemaining(c: Context): Long {
        val p = prefs(c)
        val start = p.getLong(KEY_OFF_ELAPSED, -1L)
        if (start < 0L) return FOCUS_MS
        val elapsed = SystemClock.elapsedRealtime() - start
        return (FOCUS_MS - elapsed).coerceAtLeast(0L)
    }
    fun freeRemaining(c: Context): Long =
        (prefs(c).getLong(KEY_FREE_END, 0L) - System.currentTimeMillis()).coerceAtLeast(0L)

    @Synchronized fun refresh(c: Context): Phase {
        val p = prefs(c)
        if (phase(c) == Phase.FREE) {
            if (freeRemaining(c) <= 0L) {
                p.edit().putString(KEY_PHASE, "FOCUS").putLong(KEY_FOCUS_END, 0L).apply()
            }
        } else {
            val offStart = p.getLong(KEY_OFF_ELAPSED, -1L)
            // elapsedRealtime is reset at reboot. A negative delta safely resets the qualification.
            val elapsed = if (offStart >= 0) SystemClock.elapsedRealtime() - offStart else -1L
            if (elapsed >= FOCUS_MS) {
                p.edit().putString(KEY_PHASE, "FREE")
                    .putLong(KEY_FREE_END, System.currentTimeMillis() + FREE_MS)
                    .remove(KEY_OFF_ELAPSED).remove(KEY_OFF_WALL).apply()
            }
        }
        return phase(c)
    }

    fun nextTransitionRemaining(c: Context): Long =
        if (phase(c) == Phase.FREE) freeRemaining(c) else screenOffRemaining(c)

    fun format(ms: Long): String {
        val total = (ms / 1000L).coerceAtLeast(0L)
        return "%02d:%02d".format(total / 60L, total % 60L)
    }
}
