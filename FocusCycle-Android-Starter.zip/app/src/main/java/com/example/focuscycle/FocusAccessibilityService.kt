package com.example.focuscycle

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.IntentFilter
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private val blockedPackages = setOf(
        "com.zhiliaoapp.musically",       // TikTok
        "com.ss.android.ugc.trill",       // TikTok variant in some regions
        "com.instagram.android",
        "com.android.chrome"
    )
    private var lastRedirectAt = 0L
    private var screenReceiver: BroadcastReceiver? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                when (intent.action) {
                    Intent.ACTION_SCREEN_OFF -> CycleStore.setScreenOff(context)
                    Intent.ACTION_SCREEN_ON,
                    Intent.ACTION_USER_PRESENT -> {
                        // Evaluate a completed 30-minute screen-off streak before clearing it.
                        CycleStore.refresh(context)
                        CycleStore.clearScreenOff(context)
                    }
                }
                CycleStore.refresh(context)
            }
        }
        screenReceiver = receiver
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(receiver, filter)
    }

    override fun onDestroy() {
        screenReceiver?.let { runCatching { unregisterReceiver(it) } }
        screenReceiver = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (CycleStore.refresh(this) != Phase.FOCUS) return
        val packageName = event.packageName?.toString() ?: return
        if (packageName !in blockedPackages) return

        // Debounce repeated window events. This is a deterrent, not a tamper-proof lock.
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastRedirectAt < 1200L) return
        lastRedirectAt = now
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or
                Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra("redirected_from_blocked_app", true)
        }
        runCatching { startActivity(intent) }
    }

    override fun onInterrupt() = Unit
}
